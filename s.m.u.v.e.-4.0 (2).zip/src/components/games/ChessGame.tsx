import React, { useState, useEffect, useCallback, useMemo } from 'react';
import Card from '../common/Card';
import Button from '../common/Button';
import OnlineGameHUD from './OnlineGameHUD'; // New import

// --- TYPES & CONSTANTS ---
type Piece = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
type Player = 'w' | 'b';
type SquareData = { piece: Piece; player: Player } | null;
type BoardState = (SquareData)[][];
type Position = { row: number; col: number };

const initialBoard: BoardState = [
    [{ piece: 'r', player: 'b' }, { piece: 'n', player: 'b' }, { piece: 'b', player: 'b' }, { piece: 'q', player: 'b' }, { piece: 'k', player: 'b' }, { piece: 'b', player: 'b' }, { piece: 'n', player: 'b' }, { piece: 'r', player: 'b' }],
    Array(8).fill({ piece: 'p', player: 'b' }),
    Array(8).fill(null), Array(8).fill(null), Array(8).fill(null), Array(8).fill(null),
    Array(8).fill({ piece: 'p', player: 'w' }),
    [{ piece: 'r', player: 'w' }, { piece: 'n', player: 'w' }, { piece: 'b', player: 'w' }, { piece: 'q', player: 'w' }, { piece: 'k', player: 'w' }, { piece: 'b', player: 'w' }, { piece: 'n', player: 'w' }, { piece: 'r', player: 'w' }],
];

const pieceValues: { [key in Piece]: number } = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 100 };

// --- CHESS PIECE SVG COMPONENTS ---
const pieceSVG: Record<Player, Record<Piece, string>> = {
    w: {
        p: `<path d="M22.5 36c-3.3 0-6-2.7-6-6s2.7-6 6-6s6 2.7 6 6s-2.7 6-6 6zm-2-12h4v-2c0-2.2-1.8-4-4-4h-2c-1.1 0-2 .9-2 2v2h4zm-4-4c-1.1 0-2-.9-2-2s.9-2 2-2s2 .9 2 2s-.9 2-2 2z" fill="#FFF" stroke="#000" stroke-width="1.5" stroke-linejoin="round"/>`,
        n: `<path d="M22 10c-2 0-3 2-3 4v10c0 .9-.7 1-1.5 1h-1.5c-2 0-3 2-3 4s1 4 3 4h2c1 0 1-1 1-1v-2h-2c-1 0-1-1-1-1s0-1 1-1h1c1 0 2 1 2 2v3h3c1 0 1 1 1 1v1h-2v1h4v-1c0-1 0-1-1-2h-1v-4c0-2 1-3 1-4 1-2-1-3-3-3zm-9 2c-1 0-2 1-2 2s1 2 2 2 2-1 2-2-1-2-2-2z" fill="#FFF" stroke="#000" stroke-width="1.5" stroke-linejoin="round"/>`,
        b: `<path d="M22.5 10c-2.5 0-5 3-5 3s2.5 3 5 3s5-3 5-3s-2.5-3-5-3zm0 4c-1.4 0-2.5 1.1-2.5 2.5S21.1 19 22.5 19s2.5-1.1 2.5-2.5S23.9 14 22.5 14zm-3 8l3 12 3-12h-6z" fill="#FFF" stroke="#000" stroke-width="1.